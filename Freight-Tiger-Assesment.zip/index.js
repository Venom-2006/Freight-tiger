const { processData } = require('./processor.js');
const { analyzeAnomaly } = require('./ai.js');
const { createObjectCsvWriter } = require('csv-writer');

async function run() {
    console.log("Loading and processing data...");
    const { finalData, notes } = await processData();
    
    let totalInputTokens = 0;
    let totalOutputTokens = 0;
    let aiCalls = 0;

    console.log("Running AI analysis on flagged routes...");
    for (const row of finalData) {
        if (row.needsAIFlag) {
            const aiResult = await analyzeAnomaly(row, notes);
            row.flagged = aiResult.flagged;
            row.matched_note_id = aiResult.matched_note_id;
            row.reason = aiResult.reason;
            
            totalInputTokens += aiResult.tokenLog.input;
            totalOutputTokens += aiResult.tokenLog.output;
            aiCalls++;
        } else {
            row.flagged = 'No';
            row.matched_note_id = '';
            row.reason = 'Cost is stable.';
        }
        delete row.needsAIFlag; // Remove internal flag before CSV writing
    }

    console.log("Writing output CSV...");
    const csvWriter = createObjectCsvWriter({
        path: 'submission_output.csv',
        header: [
            { id: 'route', title: 'route' },
            { id: 'week_of', title: 'week_of' },
            { id: 'cost_per_tonne_km', title: 'cost_per_tonne_km' },
            { id: 'vs_own_history', title: 'vs_own_history' },
            { id: 'vs_similar_routes', title: 'vs_similar_routes' },
            { id: 'flagged', title: 'flagged' },
            { id: 'matched_note_id', title: 'matched_note_id' },
            { id: 'reason', title: 'reason' }
        ]
    });

    await csvWriter.writeRecords(finalData);
    console.log("Done! File saved as submission_output.csv");
    
    console.log("\n--- AI USAGE LOG ---");
    console.log(`Total LLM Calls: ${aiCalls}`);
    console.log(`Total Input Tokens: ${totalInputTokens}`);
    console.log(`Total Output Tokens: ${totalOutputTokens}`);
}

run();