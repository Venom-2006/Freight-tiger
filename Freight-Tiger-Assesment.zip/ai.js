require('dotenv').config();
const Groq = require('groq-sdk');

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

async function analyzeAnomaly(row, notes) {
    const monthStr = row.week_of.substring(0, 7);
    const relevantNotes = notes.filter(n => n.date && n.date.startsWith(monthStr));
    const notesContext = relevantNotes.map(n => `ID: ${n.note_id} | Date: ${n.date} | Applies to: ${n.applies_to} | Note: ${n.note}`).join('\n');

    const prompt = `
    You are a strict freight cost auditor. A route's cost has spiked. 
    Route: ${row.route}
    Week: ${row.week_of}
    
    Available Context Notes:
    ${notesContext || "No notes available for this timeframe."}
    
    Task: Determine if any of the notes JUSTIFY this cost increase. 
    Rules:
    1. If a note explicitly explains a cost increase for this route/region/time, output: JUSTIFIED ||| [note_id] ||| Matches note [note_id]: [brief summary of why].
    2. If no notes apply to this specific route and time, you MUST output: UNEXPLAINED ||| ||| No matching note found for this route or date range. Cost rise looks unexplained and worth a human review.
    3. Do NOT hallucinate. Do NOT guess. If the note says costs were stable, it is UNEXPLAINED.
    `;

    try {
        const response = await groq.chat.completions.create({
            messages: [{ role: "user", content: prompt }],
          model: "openai/gpt-oss-20b",
            temperature: 0.0,
        });

        const tokenLog = {
            input: response.usage?.prompt_tokens || 0,
            output: response.usage?.completion_tokens || 0
        };

        const text = response.choices[0]?.message?.content || '';
        const parts = text.split('|||').map(s => s.trim());
        
        if (parts.length >= 3 && parts[0] === 'JUSTIFIED') {
            return { flagged: 'No (justified)', matched_note_id: parts[1], reason: parts[2], tokenLog };
        } else {
            return { flagged: 'Yes', matched_note_id: '', reason: parts[2] || "No matching note found for this route or date range. Cost rise looks unexplained and worth a human review.", tokenLog };
        }
    } catch (error) {
        console.error("Groq API Error:", error.message);
        return { 
            flagged: 'Yes', 
            matched_note_id: '', 
            reason: "System Error during AI evaluation.", 
            tokenLog: { input: 0, output: 0 } 
        };
    }
}

module.exports = { analyzeAnomaly };