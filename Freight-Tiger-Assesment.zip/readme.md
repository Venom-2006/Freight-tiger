# Freight Tiger Cost Auditor

## Architecture & Workflow
1. **Data Ingestion & Grouping:** Grouped shipment records by route (`origin-destination`), `route_type`, and weekly Monday date buckets (`week_of`).
2. **Baseline Calculations:**
   - **Own History:** Calculated trailing 8-week rolling average cost per tonne-km strictly prior to the current week.
   - **Peer Routes:** Calculated weekly peer average across all other routes sharing the same `route_type` (excluding the current route).
3. **Anomaly Flagging:** Routes exceeding historical and peer baselines by >10% were flagged for RAG context analysis.
4. **AI Reasoning (RAG):** Context notes were retrieved for flagged timeframes and passed to the LLM at `temperature: 0.0` to generate deterministic, hallucination-free verdicts.

## Reproducibility Verification
Executed 3 consecutive runs on the dataset. Output flags, numeric comparisons, `matched_note_id` references, and explanation verdicts matched 100% across all runs.

## Token & Cost Log (One Full Run)
- **LLM Engine:** Groq API
- **Total LLM Calls:** 7
- **Total Input Tokens:** 2,059
- **Total Output Tokens:** 1,567
- **Estimated Cost:** $0.00 (Free Tier / Open Weights)