const fs = require('fs');
const csv = require('csv-parser');

// Helper to get the Monday of a given date string
function getMonday(dateString) {
    const d = new Date(dateString);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); 
    const monday = new Date(d.setDate(diff));
    return monday.toISOString().split('T')[0];
}

async function loadCSV(filePath) {
    const results = [];
    return new Promise((resolve, reject) => {
        fs.createReadStream(filePath)
            .pipe(csv())
            .on('data', (data) => results.push(data))
            .on('end', () => resolve(results))
            .on('error', reject);
    });
}

async function processData() {
    const shipments = await loadCSV('shipment_records.csv');
    const notes = await loadCSV('context_notes.csv');

    // 1. Aggregate Weekly Data
    const weeklyData = {};
    const peerData = {}; // For calculating similar route averages

    for (const row of shipments) {
        const route = `${row.origin}-${row.destination}`;
        const weekOf = getMonday(row.shipment_date);
        const routeType = row.route_type;
        const cost = parseFloat(row.freight_cost_inr);
        const tonnesXKm = parseFloat(row.quantity_tonnes) * parseFloat(row.distance_km);

        if (!weeklyData[route]) weeklyData[route] = {};
        if (!weeklyData[route][weekOf]) {
            weeklyData[route][weekOf] = { routeType, totalCost: 0, totalTonnesXKm: 0 };
        }
        weeklyData[route][weekOf].totalCost += cost;
        weeklyData[route][weekOf].totalTonnesXKm += tonnesXKm;
    }

    const processedRows = [];

    // 2. Calculate Metrics and Baselines
    for (const route in weeklyData) {
        // Sort weeks chronologically for the 8-week lookback
        const weeks = Object.keys(weeklyData[route]).sort();
        
        for (let i = 0; i < weeks.length; i++) {
            const currentWeek = weeks[i];
            const data = weeklyData[route][currentWeek];
            const costPerTonneKm = data.totalCost / data.totalTonnesXKm;

            // Historical 8-Week Average (Strictly prior weeks)
            let historicalSum = 0;
            let historicalCount = 0;
            const lookbackStart = Math.max(0, i - 8);
            for (let j = lookbackStart; j < i; j++) {
                const pastWeekData = weeklyData[route][weeks[j]];
                historicalSum += (pastWeekData.totalCost / pastWeekData.totalTonnesXKm);
                historicalCount++;
            }
            const ownHistoryAvg = historicalCount > 0 ? (historicalSum / historicalCount) : null;

            // Store for peer calculation later
            if (!peerData[currentWeek]) peerData[currentWeek] = [];
            peerData[currentWeek].push({ route, routeType: data.routeType, costPerTonneKm });

            processedRows.push({
                route,
                week_of: currentWeek,
                routeType: data.routeType,
                cost_per_tonne_km: costPerTonneKm,
                ownHistoryAvg
            });
        }
    }

    // 3. Calculate Peer Baselines & Flag Anomalies
    const finalData = [];
    for (const row of processedRows) {
        // Find peers: same week, same routeType, EXCLUDING current route
        const peers = peerData[row.week_of].filter(p => p.routeType === row.routeType && p.route !== row.route);
        let peerSum = 0;
        for (const peer of peers) peerSum += peer.costPerTonneKm;
        const peerAvg = peers.length > 0 ? (peerSum / peers.length) : null;

        // Formatting comparisons as percentages
        const vsHistoryPct = row.ownHistoryAvg ? ((row.cost_per_tonne_km - row.ownHistoryAvg) / row.ownHistoryAvg) * 100 : 0;
        const vsPeerPct = peerAvg ? ((row.cost_per_tonne_km - peerAvg) / peerAvg) * 100 : 0;

        // Flagging Heuristic: If cost is >10% higher than its own history AND >10% higher than peers
        const isAnomaly = (vsHistoryPct > 10 && vsPeerPct > 10);

        finalData.push({
            route: row.route,
            week_of: row.week_of,
            cost_per_tonne_km: row.cost_per_tonne_km.toFixed(2),
            vs_own_history: `${vsHistoryPct >= 0 ? '+' : ''}${vsHistoryPct.toFixed(1)}% vs this route's past average`,
            vs_similar_routes: `${vsPeerPct >= 0 ? '+' : ''}${vsPeerPct.toFixed(1)}% vs similar-length routes this week`,
            needsAIFlag: isAnomaly
        });
    }

    return { finalData, notes };
}

module.exports = { processData };